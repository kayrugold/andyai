# Auto-generated baseline brain for v68
SPEC_RULES = [
    {'match': ['hi', 'hello', 'hey', 'yo'], 'reply': 'Howdy. Type status or help.', 'handled': True, 'actions': []},
    {'match': ['status'], 'reply': 'System active. Generation work in progress.', 'handled': True, 'actions': []},
    {'match': ['help'], 'reply': 'Try status, why, rules, step, run 3, or mutate common-commands.', 'handled': True, 'actions': []},
    {'match': ['what are you doing'], 'reply': "I'm running generation work and tracking self-improvement.", 'handled': True, 'actions': []},
    {'match': ['how are you'], 'reply': "I'm running generation work and tracking self-improvement.", 'handled': True, 'actions': []},
]

def _safe_reply(handled, reply, actions=None):
    if actions is None:
        actions = []
    return {
        "handled": bool(handled),
        "reply": str(reply),
        "actions": list(actions) if isinstance(actions, list) else []
    }

def _matches(t, patterns):
    for p in patterns:
        p = (p or "").strip().lower()
        if not p:
            continue
        if t == p:
            return True
    return False

def process(text, state):
    t = (text or "").strip().lower()
    state = state if isinstance(state, dict) else {}

    for rule in SPEC_RULES:
        match = rule.get("match", [])
        if _matches(t, match):
            return _safe_reply(
                rule.get("handled", True),
                rule.get("reply", ""),
                rule.get("actions", [])
            )

    return _safe_reply(False, "", [])