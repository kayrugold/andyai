from art_engine import (
    write_svg_art,
    art_status_text,
    art_gallery_text,
    art_profile_text,
    art_modes_text,
    evolve_art,
    write_art_gallery_browser,
    write_invented_art,
    discovered_modes_text,
)


def handle_art_command(
    cmd: str,
    low: str,
    state,
    db,
    save_state_fn,
    top_k_fn,
    rerank_memory_hits_fn,
):
    if low == "art status":
        print(art_status_text(state))
        return True

    if low == "art modes":
        print(art_modes_text())
        return True

    if low == "art gallery":
        print(art_gallery_text())
        return True

    if low == "art browser":
        path = write_art_gallery_browser()
        print("ART BROWSER\n")
        print(f"Path: {path}")
        return True

    if low == "art profile":
        print(art_profile_text(state))
        return True

    if low == "art evolve":
        print(evolve_art(state))
        save_state_fn(state["internal_state"])
        return True

    if low == "art invent":
        result = write_invented_art(state)
        print("ART INVENTED\n")
        print(f"Mode: {result['mode']}")
        print(f"Path: {result['path']}")
        print(f"Score: {result['score']}")
        save_state_fn(state["internal_state"])
        return True

    if low == "art discovered":
        print(discovered_modes_text(state))
        return True

    if low == "art memory":
        q = "art_artifact orbit spiral grid wave phyllotaxis svg visual"
        emb = state["embedder"].embed(q)
        hits = top_k_fn(db, emb, k=12)
        hits = rerank_memory_hits_fn(q, hits)
        print("[ART MEMORY]")
        for sscore, e in hits[:10]:
            txt = str(e.get("text", ""))[:220].replace("\n", " ")
            print(f"  {sscore:.3f} | {e.get('id')} | {txt}")
        return True

    if low.startswith("art"):
        parts = cmd.split()
        mode = "spiral"
        if len(parts) >= 2:
            mode = parts[1].strip().lower()
            if mode == "art":
                mode = "spiral"

        try:
            path = write_svg_art(state, mode=mode)
            print("ART GENERATED\n")
            print(f"Mode: {mode}")
            print(f"Path: {path}")
            save_state_fn(state["internal_state"])
        except Exception as e:
            print(f"ART ERROR: {e}")
        return True

    return False
